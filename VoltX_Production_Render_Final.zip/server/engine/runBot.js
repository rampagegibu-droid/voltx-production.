const axios = require('axios');
const strategy = require('./strategy');
const Binance = require('../exchanges/binance');

async function fetchCandles(pair='BTCUSDT', points=200){
  try{
    const coin = pair.replace('/USDT','').toLowerCase();
    const res = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin}/ohlc`, { params:{ vs_currency:'usd', days:1 } });
    if(Array.isArray(res.data) && res.data.length>0){
      return res.data.map(c=>({ t:c[0], o:c[1], h:c[2], l:c[3], c:c[4], v:0 }));
    }
  }catch(e){ console.warn('coingecko fetch failed', e.message); }
  const now = Date.now();
  const arr = [];
  for(let i=0;i<points;i++){ const price = 20000 + Math.sin(i/10)*500 + Math.random()*100; arr.push({ t: now - (points-i)*60000, o:price, h:price+10, l:price-10, c:price, v:0 }); }
  return arr;
}

async function execute(params){
  const mode = params.mode || 'paper';
  const cfg = params.config || {};
  const pair = cfg.symbol || 'BTCUSDT';
  const candles = await fetchCandles(pair, 200);
  const signal = await strategy.evaluateSignal(candles, cfg.strategy || { type:'ema_cross', params:{ fast:9, slow:21 } });

  if(mode === 'paper'){
    return { ok:true, mode:'paper', signal, last: candles[candles.length-1] };
  }

  if(mode === 'live'){
    if(process.env.ENABLE_LIVE !== 'true') throw new Error('Live trading disabled. Set ENABLE_LIVE=true in env to enable.');
    if((params.exchange || 'binance') === 'binance'){
      const ex = new Binance(params.keys.apiKey, params.keys.apiSecret, (process.env.BINANCE_TESTNET==='true'));
      if(signal === 'buy' || signal === 'sell'){
        const side = signal === 'buy' ? 'BUY' : 'SELL';
        const qty = cfg.quantity || 0.001;
        const resp = await ex.placeMarketOrder({ symbol: pair, side, quantity: qty });
        return { ok:true, mode:'live', executed: resp };
      }
    }
    return { ok:false, error:'No supported exchange or action' };
  }

  return { ok:false, error:'Unknown mode' };
}

module.exports = { execute };