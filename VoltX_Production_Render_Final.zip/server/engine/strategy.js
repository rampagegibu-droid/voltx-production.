const ind = require('./indicators');

async function evaluateSignal(candles, strategy){
  const close = candles.map(c=>c.c);
  if(strategy.type === 'ema_cross'){
    const fast = ind.ema(close, strategy.params.fast);
    const slow = ind.ema(close, strategy.params.slow);
    const i = close.length-1;
    if(i<1) return 'hold';
    if(fast[i] > slow[i] && fast[i-1] <= slow[i-1]) return 'buy';
    if(fast[i] < slow[i] && fast[i-1] >= slow[i-1]) return 'sell';
    return 'hold';
  }
  if(strategy.type === 'rsi_threshold'){
    const r = ind.rsi(close, strategy.params.period);
    const last = r[r.length-1];
    if(last === null) return 'hold';
    if(last < strategy.params.buy_below) return 'buy';
    if(last > strategy.params.sell_above) return 'sell';
    return 'hold';
  }
  return 'hold';
}

module.exports = { evaluateSignal };