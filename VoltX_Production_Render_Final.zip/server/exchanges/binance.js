const crypto = require('crypto');
const axios = require('axios');
class Binance {
  constructor(apiKey, apiSecret, testnet=true){
    this.apiKey = apiKey; this.apiSecret = apiSecret;
    this.baseURL = testnet ? 'https://testnet.binance.vision' : 'https://api.binance.com';
    this.client = axios.create({ baseURL: this.baseURL, headers: { 'X-MBX-APIKEY': this.apiKey } });
  }
  sign(query){ return crypto.createHmac('sha256', this.apiSecret).update(query).digest('hex'); }
  async getTickerPrice(symbol='BTCUSDT'){ const r = await this.client.get(`/api/v3/ticker/price?symbol=${symbol}`); return parseFloat(r.data.price); }
  async placeMarketOrder({ symbol='BTCUSDT', side='BUY', quantity }){
    if(process.env.ENABLE_LIVE !== 'true') throw new Error('Live trading disabled in environment');
    if(!this.apiKey || !this.apiSecret) throw new Error('Missing API credentials');
    const ts = Date.now();
    const params = `symbol=${symbol}&side=${side}&type=MARKET&quantity=${quantity}&timestamp=${ts}`;
    const signature = this.sign(params);
    const url = `/api/v3/order?${params}&signature=${signature}`;
    const r = await this.client.post(url);
    return r.data;
  }
}
module.exports = Binance;