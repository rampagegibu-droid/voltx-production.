const express = require('express');
const router = express.Router();
const runBot = require('../engine/runBot');
const backtester = require('../backtester/backtester');

// Run strategy (paper or live) - defaults to paper-only enforced
router.post('/run', async (req,res) => {
  try{
    const params = req.body || {};
    // ensure ENABLE_LIVE is false unless explicitly enabled in env
    if(params.mode === 'live' && process.env.ENABLE_LIVE !== 'true'){
      return res.status(403).json({ ok:false, error:'Live trading is disabled on this deployment. Use paper mode.' });
    }
    const out = await runBot.execute(params);
    res.json({ ok:true, out });
  }catch(e){
    console.error(e);
    res.status(500).json({ ok:false, error: e.message });
  }
});

router.post('/backtest', async (req,res) => {
  try{
    const { candles, config } = req.body;
    const out = backtester.runBacktest(candles, config || {});
    res.json({ ok:true, out });
  }catch(e){ res.status(500).json({ ok:false, error: e.message }); }
});

module.exports = router;