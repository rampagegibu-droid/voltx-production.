require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../client')));

// health check
app.get('/health', (req,res) => res.json({ ok:true, uptime: process.uptime() }));

// info
app.get('/', (req,res) => res.sendFile(path.join(__dirname, '../client/index.html')));

// mount engine routes
app.use('/api/engine', require('./routes/engine'));

// simple logs endpoint
app.get('/api/status', (req,res) => res.json({ env: process.env.NODE_ENV || 'development' }));

const PORT = process.env.PORT || 10000;
app.listen(PORT, '0.0.0.0', () => console.log('VoltX listening on', PORT));