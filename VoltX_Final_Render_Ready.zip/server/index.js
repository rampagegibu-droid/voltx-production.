const express=require('express');
const body=require('body-parser');
const cors=require('cors');
require('dotenv').config();

const app=express();
app.use(cors());
app.use(body.json());

app.get('/health',(req,res)=>res.json({ok:true}));

app.use('/api/engine', require('./routes/engine'));

app.listen(process.env.PORT||10000,()=>console.log("VoltX Final Live"));
