module.exports={
 async execute(p){ return {ok:true, mode:p.mode||'paper', signal:'hold'} }
};
