const express=require('express');
const router=express.Router();
const run=require('../engine/runBot');
router.post('/run', async(req,res)=>{
 try{ res.json(await run.execute(req.body)); }
 catch(e){ res.status(500).json({error:e.message}); }
});
module.exports=router;
